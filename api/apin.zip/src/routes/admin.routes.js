const express = require('express');
const { addUser, getAllUsers, updateSettings,updateUser } = require('../controllers/admin.controller');
const { protect, authorize } = require('../middlewares/auth.middleware');
const router = express.Router();

// All routes in this file are protected and require admin role
router.use(protect, authorize('admin'));

router.post('/users', addUser);
router.get('/users', getAllUsers);
router.put('/settings', updateSettings);
router.route('/users/:id')
    .put(updateUser); 
module.exports = router;