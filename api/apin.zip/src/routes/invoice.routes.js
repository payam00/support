const express = require('express');
const router = express.Router();
const { protect, authorize } = require('../middlewares/auth.middleware');
const { createInvoice, getInvoices, getInvoiceByToken, acceptInvoiceTerms,applyDiscount  } = require('../controllers/invoice.controller');

const staffRoles = ['operator', 'department_head', 'admin'];

// Private routes for staff
router.route('/')
    .post(protect, authorize(...staffRoles), createInvoice)
    .get(protect, authorize(...staffRoles), getInvoices);

// Public routes for end-user
router.route('/public/:token').get(getInvoiceByToken);
router.route('/public/:token/accept').post(acceptInvoiceTerms);
router.route('/public/:token/apply-discount').post(applyDiscount);


module.exports = router;