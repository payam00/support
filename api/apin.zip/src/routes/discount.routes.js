const express = require('express');
const router = express.Router();
const { protect, authorize } = require('../middlewares/auth.middleware');
const { getDiscounts, createDiscount } = require('../controllers/discount.controller');

router.use(protect, authorize('admin'));

router.route('/')
    .get(getDiscounts)
    .post(createDiscount);

module.exports = router;