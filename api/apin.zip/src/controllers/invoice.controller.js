const Invoice = require('../models/invoice.model');
const ClassType = require('../models/classType.model');

// @desc    Create an invoice
// @route   POST /api/invoices
// @access  Private (Operator, Head, Admin)
exports.createInvoice = async (req, res) => {
    try {
        const { fullName, nationality, nationalId, mobileNumber, classTypeId, amount } = req.body;
        
        if (nationality === 'iranian' && !nationalId) {
            return res.status(400).json({ message: 'کد ملی برای اتباع ایرانی الزامی است.' });
        }

        const classType = await ClassType.findById(classTypeId);
        if (!classType) {
            return res.status(404).json({ message: 'نوع کلاس انتخاب شده معتبر نیست.' });
        }
const settings = await Setting.findOne();
        const validityHours = settings.invoiceValidityHours || 24;
        const invoice = await Invoice.create({
            fullName,
            nationality,
            nationalId,
            mobileNumber,
            classType: classTypeId,
            amount: amount || classType.price, // اگر مبلغ ارسال نشد از قیمت کلاس استفاده کن
            createdBy: req.user._id,
            expiresAt: new Date(Date.now() + validityHours * 3600 * 1000),

        });

        res.status(201).json({ message: 'فاکتور با موفقیت صادر شد.', invoice });
    } catch (error) {
        res.status(500).json({ message: 'خطای سرور', error: error.message });
    }
};

// @desc    Get all invoices (for staff)
// @route   GET /api/invoices
// @access  Private (Operator, Head, Admin)
exports.getInvoices = async (req, res) => {
    try {
        const { search, status } = req.query;
        let query = {};

        // Permission Filter
        if (!req.user.permissions.canViewAllInvoices && req.user.role !== 'admin') {
            query.createdBy = req.user._id;
        }

        // Status Filter
        if (status && ['pending', 'paid', 'canceled', 'expired'].includes(status)) {
            query.status = status;
        }

        // Search Filter
        if (search) {
            query.$or = [
                { fullName: { $regex: search, $options: 'i' } },
                { mobileNumber: { $regex: search, $options: 'i' } },
                { nationalId: { $regex: search, $options: 'i' } }
            ];
        }

        const invoices = await Invoice.find(query)
            .populate('createdBy', 'name')
            .populate('classType', 'name')
            .sort({ createdAt: -1 });
        res.status(200).json(invoices);
    } catch (error) {
        res.status(500).json({ message: 'خطای سرور' });
    }
};
// @desc    Export invoices to CSV
exports.exportInvoices = async (req, res) => {
    try {
        const invoices = await Invoice.find({})
            .populate('createdBy', 'name')
            .populate('classType', 'name');

        const fields = [
            { label: 'نام مشتری', value: 'fullName' },
            { label: 'موبایل', value: 'mobileNumber' },
            { label: 'نوع کلاس', value: 'classType.name' },
            { label: 'مبلغ نهایی', value: 'finalAmount' },
            { label: 'وضعیت', value: 'status' },
            { label: 'صادر کننده', value: 'createdBy.name' },
            { label: 'تاریخ صدور', value: 'createdAt' },
        ];
        
        const csv = json2csv(invoices, { fields });
        res.header('Content-Type', 'text/csv');
        res.attachment('invoices.csv');
        res.send(csv);
    } catch (error) {
        res.status(500).json({ message: 'خطا در ایجاد خروجی' });
    }
};
// @desc    Get single invoice by public token
// @route   GET /api/invoices/public/:token
// @access  Public
exports.getInvoiceByToken = async (req, res) => {
    try {
        const invoice = await Invoice.findOne({ uniqueToken: req.params.token })
            .populate('classType', 'name price termsAndConditions');
            
        if (!invoice) {
            return res.status(404).json({ message: 'فاکتور مورد نظر یافت نشد.' });
        }
        res.status(200).json(invoice);
    } catch (error) {
        res.status(500).json({ message: 'خطای سرور' });
    }
};

// @desc    Accept terms and proceed to payment
// @route   POST /api/invoices/public/:token/accept
// @access  Public
exports.acceptInvoiceTerms = async (req, res) => {
    try {
        const invoice = await Invoice.findOne({ uniqueToken: req.params.token });
        if (!invoice) {
            return res.status(404).json({ message: 'فاکتور یافت نشد.' });
        }
        if (invoice.status !== 'pending') {
            return res.status(400).json({ message: 'این فاکتور دیگر معتبر نیست.' });
        }
        invoice.termsAccepted = true;
        // در اینجا می‌توانید منطق اتصال به درگاه پرداخت را اضافه کنید
        // فعلا فقط وضعیت را آپدیت می‌کنیم
        await invoice.save();
        res.status(200).json({ message: 'قوانین تایید شد. در حال انتقال به صفحه پرداخت...', invoice });
    } catch (error) {
        res.status(500).json({ message: 'خطای سرور' });
    }
};