const Discount = require('../models/discount.model');
const Invoice = require('../models/invoice.model');

// @desc    Get all discounts
// @route   GET /api/discounts
// @access  Admin
exports.getDiscounts = async (req, res) => {
    try {
        const discounts = await Discount.find();
        res.status(200).json(discounts);
    } catch (error) {
        res.status(500).json({ message: 'خطای سرور' });
    }
};

// @desc    Create a new discount
// @route   POST /api/discounts
// @access  Admin
exports.createDiscount = async (req, res) => {
    try {
        const { code, type, value, usageLimit, expiresAt } = req.body;
        const newDiscount = await Discount.create({ code, type, value, usageLimit, expiresAt });
        res.status(201).json(newDiscount);
    } catch (error) {
        if (error.code === 11000) {
            return res.status(409).json({ message: 'این کد تخفیف قبلاً ثبت شده است.' });
        }
        res.status(500).json({ message: 'خطای سرور', error: error.message });
    }
};

// @desc    Apply a discount code to an invoice
// @route   POST /api/invoices/public/:token/apply-discount
// @access  Public
exports.applyDiscount = async (req, res) => {
    try {
        const { code } = req.body;
        if (!code) {
            return res.status(400).json({ message: 'کد تخفیف الزامی است.' });
        }

        const discount = await Discount.findOne({ code: code.toUpperCase(), isActive: true });
        if (!discount) {
            return res.status(404).json({ message: 'کد تخفیف نامعتبر است.' });
        }

        if (discount.expiresAt && new Date(discount.expiresAt) < new Date()) {
            return res.status(400).json({ message: 'این کد تخفیف منقضی شده است.' });
        }

        if (discount.timesUsed >= discount.usageLimit) {
            return res.status(400).json({ message: 'ظرفیت استفاده از این کد تخفیف به اتمام رسیده است.' });
        }
        
        const invoice = await Invoice.findOne({ uniqueToken: req.params.token });
        if (!invoice) {
            return res.status(404).json({ message: 'فاکتور یافت نشد.' });
        }
        if (invoice.status !== 'pending') {
            return res.status(400).json({ message: 'امکان اعمال تخفیف روی این فاکتور وجود ندارد.' });
        }

        let discountAmount = 0;
        if (discount.type === 'percentage') {
            discountAmount = (invoice.amount * discount.value) / 100;
        } else { // fixed_amount
            discountAmount = discount.value;
        }

        invoice.finalAmount = Math.max(0, invoice.amount - discountAmount);
        invoice.discount = {
            code: discount.code,
            amount: discountAmount
        };
        
        // Note: We don't increment timesUsed here. We do it after successful payment.
        await invoice.save();

        res.status(200).json({ message: 'تخفیف با موفقیت اعمال شد.', invoice });

    } catch (error) {
        res.status(500).json({ message: 'خطای سرور' });
    }
};